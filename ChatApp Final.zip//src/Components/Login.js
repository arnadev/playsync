import React from "react";
import { auth, googleProvider, db } from "../firebase";
import { signInWithPopup } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";

const Login = ({ setUser }) => {
  const handleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      const userRef = doc(db, "users", user.uid);
      await setDoc(userRef, {
        name: user.displayName,
        email: user.email,
        uid: user.uid,
        photoURL: user.photoURL,
      });
      setUser(user);
    } catch (error) {
      console.error("Error logging in:", error);
    }
  };

  const styles = {
    container: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      height: "100vh",
      background: "linear-gradient(135deg, #6e8efb, #a777e3)",
      fontFamily: "Arial, sans-serif",
      padding: "10px", // Padding for better display on small screens
    },
    card: {
      backgroundColor: "#fff",
      color: "#333",
      padding: "30px 20px", // Adjust padding for smaller screens
      borderRadius: "12px",
      boxShadow: "0 4px 10px rgba(0, 0, 0, 0.2)",
      textAlign: "center",
      maxWidth: "360px", // Reduce max width for mobile screens
      width: "100%",
    },
    title: {
      fontSize: "1.5em", // Slightly smaller title for mobile
      marginBottom: "15px",
      color: "#2c3e50",
    },
    description: {
      fontSize: "1em",
      marginBottom: "20px",
      color: "#555",
    },
    button: {
      backgroundColor: "#4285F4",
      color: "white",
      border: "none",
      padding: "12px 18px",
      borderRadius: "6px",
      fontSize: "1em",
      cursor: "pointer",
      transition: "background-color 0.3s",
      width: "100%",
      maxWidth: "200px", // Restrict button width for better fit
    },
    buttonHover: {
      backgroundColor: "#357ae8",
    },
    footer: {
      marginTop: "20px",
      fontSize: "0.9em",
      color: "#777",
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>Welcome to PlaySync Chat</h1>
        <p style={styles.description}>Sign in to continue to your account.</p>
        <button
          style={styles.button}
          onMouseOver={(e) =>
            (e.target.style.backgroundColor =
              styles.buttonHover.backgroundColor)
          }
          onMouseOut={(e) =>
            (e.target.style.backgroundColor = styles.button.backgroundColor)
          }
          onClick={handleLogin}
        >
          Login with Google
        </button>
        <div style={styles.footer}>
          <p>Your data is safe with us.</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
