import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  arrayUnion,
  onSnapshot,
} from "firebase/firestore";
import { db } from "../firebase";

const Messages = ({ chat, user }) => {
  const [newMessage, setNewMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [userProfiles, setUserProfiles] = useState({});
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const messagesMemo = useMemo(() => messages, [messages]);

  useEffect(() => {
    if (!chat?.participants) return;

    setMessages([]);
    const sortedParticipants = [...chat.participants].sort();
    const chatId = `${sortedParticipants[0]}_${sortedParticipants[1]}`;
    const chatRef = doc(db, "chats", chatId);

    const unsubscribe = onSnapshot(chatRef, (docSnapshot) => {
      if (docSnapshot.exists()) {
        const fetchedMessages = docSnapshot.data().messages || [];
        setMessages(fetchedMessages);
      }
    });

    return () => unsubscribe();
  }, [chat]);

  useEffect(() => {
    const fetchUserProfiles = async () => {
      try {
        const userProfilePromises = chat.participants.map(
          async (participantId) => {
            const userRef = doc(db, "users", participantId);
            const userDoc = await getDoc(userRef);
            return {
              uid: participantId,
              profilePic: userDoc.data()?.profilePic,
            };
          }
        );

        const userProfilesData = await Promise.all(userProfilePromises);
        const profiles = userProfilesData.reduce((acc, { uid, profilePic }) => {
          acc[uid] = profilePic;
          return acc;
        }, {});

        setUserProfiles(profiles);
      } catch (error) {
        console.error("Error fetching user profiles:", error);
      }
    };

    if (chat?.participants) {
      fetchUserProfiles();
    }
  }, [chat]);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messagesMemo]);

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    setLoading(true);

    try {
      const sortedParticipants = [...chat.participants].sort();
      const chatId = `${sortedParticipants[0]}_${sortedParticipants[1]}`;
      const chatRef = doc(db, "chats", chatId);

      const chatDoc = await getDoc(chatRef);
      if (!chatDoc.exists()) {
        await setDoc(chatRef, {
          participants: sortedParticipants,
          name: chat.name || "Chat",
          messages: [],
        });
      }

      await updateDoc(chatRef, {
        messages: arrayUnion({
          text: newMessage,
          senderId: user.uid,
          timestamp: new Date(),
        }),
      });

      setNewMessage("");
    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  };

  const styles = {
    container: {
      maxWidth: "600px",
      margin: "20px auto",
      padding: "15px",
      backgroundColor: "#f9f9f9",
      borderRadius: "15px",
      boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
      display: "flex",
      flexDirection: "column",
    },
    header: {
      background: "linear-gradient(135deg, #4caf50, #66bb6a)",
      color: "#fff",
      padding: "15px",
      borderRadius: "10px",
      fontSize: "1.5em",
      fontWeight: "bold",
      textAlign: "center",
    },
    messagesContainer: {
      flex: 1,
      maxHeight: "400px",
      overflowY: "auto",
      padding: "10px",
      display: "flex",
      flexDirection: "column",
      gap: "10px",
    },
    message: {
      display: "flex",
      flexDirection: "column",
      gap: "5px",
    },
    sent: {
      alignItems: "flex-end",
    },
    received: {
      alignItems: "flex-start",
    },
    messageText: {
      padding: "12px 18px",
      borderRadius: "20px",
      maxWidth: "75%",
      fontSize: "1em",
      wordWrap: "break-word",
    },
    sentText: {
      background: "#4caf50",
      color: "#fff",
    },
    receivedText: {
      backgroundColor: "#e0e0e0",
      color: "#333",
    },
    timestamp: {
      fontSize: "0.75em",
      color: "#aaa",
    },
    inputContainer: {
      display: "flex",
      gap: "10px",
      padding: "10px",
      borderTop: "1px solid #ddd",
    },
    input: {
      flex: 1,
      padding: "12px",
      borderRadius: "20px",
      border: "1px solid #ddd",
    },
    button: {
      padding: "10px",
      borderRadius: "20px",
      background: "#4caf50",
      color: "#fff",
      border: "none",
    },
    "@media (max-width: 600px)": {
      container: {
        padding: "10px",
      },
      inputContainer: {
        flexDirection: "column",
      },
      button: {
        width: "100%",
      },
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>{`Chat with ${chat.name}`}</div>
      <div style={styles.messagesContainer}>
        {messages.map((message, index) => (
          <div
            key={index}
            style={{
              ...styles.message,
              ...(message.senderId === user.uid
                ? styles.sent
                : styles.received),
            }}
          >
            <div
              style={{
                ...styles.messageText,
                ...(message.senderId === user.uid
                  ? styles.sentText
                  : styles.receivedText),
              }}
            >
              {message.text}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <div style={styles.inputContainer}>
        <input
          type="text"
          placeholder="Type a message..."
          style={styles.input}
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyPress={handleKeyPress}
        />
        <button style={styles.button} onClick={sendMessage} disabled={loading}>
          {loading ? "Sending..." : "Send"}
        </button>
      </div>
    </div>
  );
};

export default Messages;
