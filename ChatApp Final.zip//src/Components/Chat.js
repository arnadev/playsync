import React, { useState, useEffect, useRef } from "react";
import UsersSearch from "./UsersSearch";
import Messages from "./Messages";

const Chat = ({ user }) => {
  const [selectedChat, setSelectedChat] = useState(null);
  const chatAreaRef = useRef();

  useEffect(() => {
    if (chatAreaRef.current) {
      chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
    }
  }, [selectedChat]);

  const styles = {
    container: {
      padding: "10px",
      fontFamily: "'Arial', sans-serif",
      background: "linear-gradient(135deg, #f3f4f6, #e9ecef)",
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-start",
    },
    header: {
      fontSize: "2em",
      marginBottom: "15px",
      color: "#2c3e50",
      textAlign: "center",
      textShadow: "1px 1px 2px rgba(0, 0, 0, 0.1)",
    },
    chatAreaContainer: {
      display: "flex",
      flexDirection: "column",
      flexGrow: 1,
    },
    chatArea: {
      marginTop: "10px",
      padding: "10px",
      backgroundColor: "#fff",
      borderRadius: "10px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
      height: "60vh", // Adjust height for mobile
      overflowY: "auto",
    },
    noChatMessage: {
      color: "#7f8c8d",
      fontStyle: "italic",
      textAlign: "center",
      fontSize: "1em",
      marginTop: "50%",
    },
    // Mobile-specific adjustments
    "@media (max-width: 768px)": {
      header: {
        fontSize: "1.5em",
      },
      chatArea: {
        height: "50vh", // Further reduce height for smaller screens
      },
    },
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>Welcome, {user.displayName}</h1>
      <UsersSearch setSelectedChat={setSelectedChat} user={user} />
      <div style={styles.chatAreaContainer}>
        <div style={styles.chatArea} ref={chatAreaRef}>
          {selectedChat ? (
            <Messages chat={selectedChat} user={user} />
          ) : (
            <p style={styles.noChatMessage}>Select a user to chat with.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Chat;
