import React, { useState, useEffect } from "react";
import {
  collection,
  query,
  where,
  getDocs,
  onSnapshot,
  doc,
  getDoc,
} from "firebase/firestore";
import { db } from "../firebase";

const UsersSearch = ({ setSelectedChat, user }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [users, setUsers] = useState([]);
  const [chats, setChats] = useState([]);
  const [newMessages, setNewMessages] = useState(new Set()); // Set to track chats with new messages
  const [selectedTab, setSelectedTab] = useState(null);

  // Fetch user's existing chats
  useEffect(() => {
    const fetchChats = async () => {
      const chatsRef = collection(db, "chats");
      const q = query(
        chatsRef,
        where("participants", "array-contains", user.uid)
      );

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const fetchedChats = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setChats(fetchedChats);
      });

      return () => unsubscribe();
    };

    fetchChats();
  }, [user.uid]);

  // Search for users
  const handleSearch = async () => {
    if (!searchTerm.trim()) return;

    const usersRef = collection(db, "users");
    const q = query(
      usersRef,
      where("name", ">=", searchTerm),
      where("name", "<=", searchTerm + "\uf8ff") // Ensures case-insensitive matching and matches names starting with the search term
    );

    const querySnapshot = await getDocs(q);
    const results = [];

    querySnapshot.forEach((doc) => {
      if (doc.id !== user.uid) {
        results.push({ uid: doc.id, ...doc.data() });
      }
    });
    setUsers(results);
  };

  const selectUser = (selectedUser) => {
    setSelectedChat({
      participants: [user.uid, selectedUser.uid],
      name: selectedUser.name,
    });
    setSelectedTab(selectedUser.uid);
    // Remove the chat from newMessages when the user opens it
    setNewMessages((prev) => {
      const updatedMessages = new Set(prev);
      updatedMessages.delete(selectedUser.uid);
      return updatedMessages;
    });
  };

  const selectChat = (chat) => {
    setSelectedChat(chat);
    setSelectedTab(chat.id);
    // Remove the chat from newMessages when the user opens it
    setNewMessages((prev) => {
      const updatedMessages = new Set(prev);
      updatedMessages.delete(chat.id);
      return updatedMessages;
    });
  };

  // Listen for new messages and mark chats with new messages
  useEffect(() => {
    const trackNewMessages = (chatId) => {
      // Correctly query the chats collection
      const chatQuery = query(
        collection(db, "chats"),
        where("id", "==", chatId)
      );

      const unsubscribe = onSnapshot(chatQuery, (snapshot) => {
        snapshot.docs.forEach((doc) => {
          const chatData = doc.data();
          if (chatData.messages) {
            const lastMessage = chatData.messages[chatData.messages.length - 1];
            if (lastMessage && lastMessage.senderId !== user.uid) {
              // If the last message was from another user, mark this chat as having new messages
              setNewMessages((prev) => {
                const updatedMessages = new Set(prev);
                updatedMessages.add(chatId); // Add chatId to the newMessages set
                return updatedMessages;
              });
            }
          }
        });
      });

      return unsubscribe;
    };

    chats.forEach((chat) => {
      trackNewMessages(chat.id);
    });
  }, [chats, user.uid]);

  const fetchParticipantName = async (participantId) => {
    const userDocRef = doc(db, "users", participantId);
    const userDocSnap = await getDoc(userDocRef);
    if (userDocSnap.exists()) {
      return userDocSnap.data().name;
    }
    return null;
  };

  const styles = {
    container: {
      width: "100%",
      maxWidth: "600px", // Increased max-width for larger screens
      margin: "0 auto",
      padding: "20px",
      backgroundColor: "#f4f4f4",
      borderRadius: "8px",
      boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
      fontFamily: "Arial, sans-serif",
      boxSizing: "border-box",
    },
    inputContainer: {
      marginBottom: "20px",
      display: "flex",
      flexDirection: "column", // Stack on mobile
      justifyContent: "center",
      gap: "10px",
    },
    input: {
      width: "100%",
      padding: "12px",
      fontSize: "16px", // Slightly larger text for easier readability
      borderRadius: "4px",
      border: "1px solid #ccc",
    },
    button: {
      padding: "12px 20px",
      backgroundColor: "#007bff",
      color: "white",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
      fontSize: "16px",
      transition: "background-color 0.3s",
      width: "100%",
    },
    buttonHover: {
      backgroundColor: "#0056b3",
    },
    tabContainer: {
      display: "flex",
      flexDirection: "column",
      marginTop: "20px",
    },
    tab: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "15px",
      marginBottom: "10px",
      backgroundColor: "#fff",
      borderRadius: "6px",
      cursor: "pointer",
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
      transition: "background-color 0.3s",
      position: "relative",
      fontSize: "16px", // Larger font size for better visibility
    },
    tabSelected: {
      backgroundColor: "#007bff",
      color: "white",
    },
    tabButton: {
      padding: "6px 12px",
      backgroundColor: "#28a745",
      color: "white",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
      fontSize: "14px",
    },
    tabButtonHover: {
      backgroundColor: "#218838",
    },
    noResults: {
      textAlign: "center",
      color: "#888",
    },
    sectionHeader: {
      fontWeight: "bold",
      marginBottom: "10px",
      fontSize: "18px", // Larger font size for section headers
    },
    redDot: {
      position: "absolute",
      top: "5px",
      right: "5px",
      backgroundColor: "#dc3545",
      width: "10px",
      height: "10px",
      borderRadius: "50%",
    },
    "@media (max-width: 600px)": {
      // Media query for mobile devices
      container: {
        padding: "10px",
      },
      input: {
        fontSize: "14px",
      },
      button: {
        fontSize: "14px",
        padding: "10px",
      },
      tab: {
        fontSize: "14px",
        padding: "10px",
      },
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.inputContainer}>
        <input
          type="text"
          placeholder="Search for users"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={styles.input}
        />
        <button
          onClick={handleSearch}
          style={styles.button}
          onMouseEnter={(e) =>
            (e.target.style.backgroundColor =
              styles.buttonHover.backgroundColor)
          }
          onMouseLeave={(e) =>
            (e.target.style.backgroundColor = styles.button.backgroundColor)
          }
        >
          Search
        </button>
      </div>

      {chats.length > 0 && (
        <div style={styles.tabContainer}>
          <div style={styles.sectionHeader}>Your Chats</div>
          {chats.map((chat) => {
            const otherParticipant = chat.participants.find(
              (participant) => participant !== user.uid
            );
            fetchParticipantName(otherParticipant).then((name) => {
              chat.otherParticipantName = name;
            });

            return (
              <div
                key={chat.id}
                style={{
                  ...styles.tab,
                  ...(selectedTab === chat.id ? styles.tabSelected : {}),
                }}
                onClick={() => selectChat(chat)}
              >
                <span>{chat.otherParticipantName || "Loading..."}</span>
                {newMessages.has(chat.id) && selectedTab !== chat.id && (
                  <div style={styles.redDot}></div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {users.length > 0 && (
        <div style={styles.tabContainer}>
          <div style={styles.sectionHeader}>Search Results</div>
          {users.map((user) => (
            <div
              key={user.uid}
              style={{
                ...styles.tab,
                ...(selectedTab === user.uid ? styles.tabSelected : {}),
              }}
              onClick={() => selectUser(user)}
            >
              <span>{user.name}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  selectUser(user);
                }}
                style={styles.tabButton}
                onMouseEnter={(e) =>
                  (e.target.style.backgroundColor =
                    styles.tabButtonHover.backgroundColor)
                }
                onMouseLeave={(e) =>
                  (e.target.style.backgroundColor =
                    styles.tabButton.backgroundColor)
                }
              >
                Chat
              </button>
            </div>
          ))}
        </div>
      )}

      {users.length === 0 && chats.length === 0 && (
        <p style={styles.noResults}>No users or chats found.</p>
      )}
    </div>
  );
};

export default UsersSearch;
