import React, { useState } from "react";
import Login from "./Components/Login";
import Chat from "./Components/Chat";
import "./styles.css";

const App = () => {
  const [user, setUser] = useState(null);

  return <div>{user ? <Chat user={user} /> : <Login setUser={setUser} />}</div>;
};

export default App;
