import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBUqlcfC0TIUsgApLK_fBMHwiISkYpjj1Q",
  authDomain: "chats-c0b26.firebaseapp.com",
  projectId: "chats-c0b26",
  storageBucket: "chats-c0b26.firebasestorage.app",
  messagingSenderId: "536864415476",
  appId: "1:536864415476:web:dd86cf35e03e0febd008a1",
  measurementId: "G-LHVJ67WFH3",
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);
